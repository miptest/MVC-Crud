﻿
$(document).ready(function () {
    
    $('#add').click(function (event) {
        event.preventDefault();
        $.get(this.href, function (response) {
            $('.divForAdd').html(response);
        });
        $('#addmodel').modal({
            backdrop: 'static',
        }, 'show');
    });

    $('.openDialog-Edit').click(function (event) {
        event.preventDefault();
        $.get(this.href, function (response) {
            $('.divForCreate').html(response);
        });
        $('#editmodel').modal({
            backdrop: 'static',
        }, 'show');
    });

});