﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace MIP.Models
{
    public class EmployeeModel
    {

        public int ID { get; set; }
        
        [Required]
        [Display(Name = "Name")]
        public string Name { get; set; }
        
        [Required]
        [Display(Name = "EmailID")]
        public string EmailID { get; set; }

        public string Position { get; set; }

        public string City { get; set; }
        [Required]
        [Display(Name = "Salary")]
        public string Salary { get; set; }

        public byte[] Image { get; set; }
    }
}