﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Web;
using MIP.DAL;
using MIP.DAL.DB;
using MIP.BLL;
namespace MIP.BLL
{
    public interface IContentRepository
    {
        //a.An interface looks like a class, but has no implementation. The only thing it contains are declarations of events, indexers, methods and/or properties. 
        //b.We can not use any access modifier i.e. public , private , protected , internal etc. because within an interface by default everything is public.
        //c. An Interface member cannot be defined using the keyword static, virtual, abstract or sealed.
        //d.Interface support multiple inheritance.

        //Advantage
        //a.We Can Define what type methods and properties.
        //b.To avoid un wanted methods and properties.

        List<EmployeeDetail> EmployeeList();
        EmployeeDetail Find(int Id);
        string Insert(HttpPostedFileBase file, EmployeeDetail model);
        string Edit(HttpPostedFileBase file, EmployeeDetail model);
        string DeleteImage(int id);
        string Delete(int id);
        byte[] ConvertToBytes(HttpPostedFileBase image);
        byte[] GetImageFromDataBase(int Id);
    }

    public class ContentRepository : DbContext, IContentRepository
    {

        public List<EmployeeDetail> EmployeeList()
        {
            try
            {
                List<EmployeeDetail> List = new List<EmployeeDetail>();
                List = dbConn.EmployeeDetails.OrderByDescending(x => x.ID).ToList();
                return List;
            }
            catch (Exception)
            {

                throw;
            }

        }

        public EmployeeDetail Find(int Id)
        {
            EmployeeDetail List = new EmployeeDetail();
            List = dbConn.EmployeeDetails.Find(Id);
            dbConn.Database.Connection.Close();
            return List;
        }

        public string Insert(HttpPostedFileBase file, EmployeeDetail model)
        {
            dbConn.Database.Connection.Open();
            model.Image = ConvertToBytes(file);
            dbConn.InsertEmployee(model.Name, model.EmailID, model.Position, model.City, model.Salary, model.Image);
            //dbConn.EmployeeDetails.Add(model);
            //dbConn.SaveChanges();
            return showMessage("Added Successfully");
        }

        public string Edit(HttpPostedFileBase file, EmployeeDetail editmodel)
        {
            dbConn.Database.Connection.Open();
            EmployeeDetail EditList = dbConn.EmployeeDetails.Where(x => x.ID == editmodel.ID).SingleOrDefault();
            EditList.ID = editmodel.ID;
            EditList.City = editmodel.City;
            EditList.EmailID = editmodel.EmailID;
            EditList.Name = editmodel.Name;
            EditList.Position = editmodel.Position;
            EditList.Salary = editmodel.Salary;
            if (file.FileName != "")
            {
                EditList.Image = ConvertToBytes(file);
            }
            dbConn.Entry(EditList).State = System.Data.Entity.EntityState.Modified;
            dbConn.SaveChanges();
           return showMessage("Updated Successfully");;
        }

        public string DeleteImage(int id)
        {
            dbConn.Database.Connection.Open();
            EmployeeDetail EditList = dbConn.EmployeeDetails.Where(x => x.ID == id).SingleOrDefault();
            EditList.Image = null;
            dbConn.Entry(EditList).State = System.Data.Entity.EntityState.Modified;
            dbConn.SaveChanges();
            return showMessage("Deleted Image Successfully");;
        }

        public string Delete(int id)
        {
            DbContext.dbConn.EmployeeDetails.Remove(DbContext.dbConn.EmployeeDetails.Find(id));
            DbContext.dbConn.SaveChanges();
            return showMessage("Deleted Successfully");;
        }

        public byte[] ConvertToBytes(HttpPostedFileBase image)
        {
            byte[] imageBytes = null;
            BinaryReader reader = new BinaryReader(image.InputStream);
            imageBytes = reader.ReadBytes((int)image.ContentLength);
            return imageBytes;
        }

        public byte[] GetImageFromDataBase(int Id)
        {
            var q = from temp in dbConn.EmployeeDetails where temp.ID == Id select temp.Image;
            byte[] cover = q.First();
            return cover;
        }

        public override string showMessage(string message)
        {
            return message;
        }
    }
}
