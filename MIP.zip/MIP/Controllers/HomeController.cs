﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MIP.DAL.DB;
using MIP.BLL;
using MIP.DAL;
using System.Data.Entity.Infrastructure;
namespace MIP.Controllers
{
    public class HomeController : Controller
    {
        //MVC Exception Handling

        //1. Try Catch 
        //2. Handle Error Info
        //3. Handle Error
        //4. Http Error
        //5. Global Error Handling In MVC
        
        
        public ContentRepository Repository = new ContentRepository();

        //[HandleError(ExceptionType = typeof(DbUpdateException), View = "Error")]
        public ActionResult Index()
        {

            return View(Repository.EmployeeList());
            
            //try
            //{
            //    return View(Repository.EmployeeList());
            //}
            //catch (Exception ex)
            //{
            //    //Method 1
            //    throw ex;

            //    //Method 2
            //   //return View("Error", new HandleErrorInfo(ex, "Home", "Index"));
            //}
        }

        public ActionResult Add()
        {
            return PartialView();
        }

        [HttpPost]
        public ActionResult Add(EmployeeDetail model)
        {
            HttpPostedFileBase file = Request.Files["ImageData"];
            if (ModelState.IsValid)
            {
                try
                {
                    var value = Repository.Insert(file, model);
                    ViewBag.Message = value;
                }
                catch (Exception ex)
                {
                    // TempData["Failure"] = ex;
                    View("Error", new HandleErrorInfo(ex, "Home", "Index"));
                }
            }
            else
            {
                TempData["Failure"] = "Record Not Saved";
            }
            return RedirectToAction("Index");
        }

        public ActionResult Edit(int id)
        {
            return PartialView(Repository.Find(id));
        }


        [HttpPost]
        public ActionResult Edit(EmployeeDetail model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    HttpPostedFileBase file = Request.Files["ImageData"];
                    var value = Repository.Edit(file, model);
                    ViewBag.Message = value;
                }
                catch (Exception ex)
                {
                    TempData["Failure"] = ex;
                }
            }
            else
            {
                TempData["Failure"] = "Record Not Saved";
            }
            return RedirectToAction("Index");
        }

        public ActionResult Delete(int id)
        {
            var value = Repository.Delete(id);
            ViewBag.Message = value;
            return RedirectToAction("Index");
        }
        public ActionResult DeleteImage(int id)
        {
            var value = Repository.DeleteImage(id);
            ViewBag.Message = value;
            return RedirectToAction("Index");
        }
        public ActionResult RetrieveImage(int id)
        {
            byte[] cover = Repository.GetImageFromDataBase(id);
            if (cover != null)
            {
                return File(cover, "image/jpg");
            }
            else
            {
                return null;
            }
        }


    }
}